You don't need to install anything extra to get this working. 
To create a new test suite, run the following command:

php artisan make:test <fileName> [--unit]

And make sure you're using the TestCase class that is under Tests and not under PhpUnit.

Move ExampleTest.php to the tests folder and testNotification.php to app/Notifications folder.  