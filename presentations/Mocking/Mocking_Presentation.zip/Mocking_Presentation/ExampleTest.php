<?php

namespace Tests\Unit;

use App\Notifications\testNotification;
use Illuminate\Http\UploadedFile;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\Bus;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Facades\Storage;
use PhpOption\Some;
use Symfony\Contracts\Service\Attribute\SubscribedService;
//use PHPUnit\Framework\TestCase;

use Illuminate\Support\Facades\Cookie;

use Tests\TestCase;

use Mockery\MockInterface;

class SomeDependency{
     public function foo($a){
         return "bar" . $a ;
     }

     public function marco($a){
         return "polo" . $a ;
     }
}

class SUT{
    use Notifiable;
    private SomeDependency $dependency;

    public function getKey(){
        return 'key';
    }
    public function __construct($dependency)
    {
        $this->dependency = $dependency;
    }

    public function callFoo($a){
        return $this->dependency->foo($a);
    }

    public function callMarco($a){
        return $this->dependency->marco($a);
    }

    public function callFooMarco($a){
        return $this->dependency->foo($a) . $this->dependency->marco($a);
    }
}

class ExampleTest extends TestCase
{
    public function test_Mock(){
        $mock = $this->mock(SomeDependency::class, function (MockInterface $mock) {
            $mock -> shouldReceive('foo')->once()
                ->with('banana')
                ->andReturn('apple');
        });
        $sut = new SUT($mock);

        echo $sut->callFoo('banana');       // returns apple (instead of barbanana)
//        echo $sut->callMarco('banana');     // throws a BadMethodCallException

        $mock->shouldHaveReceived('foo');
    }

    public function test_PartialMock(){
        $mock = $this->partialMock(SomeDependency::class, function (MockInterface $mock){
            $mock ->shouldReceive('foo')->once()
                    ->andReturn('apple');
        });

        $sut = new SUT($mock);

        echo $sut->callFoo('banana');       // returns apple (instead of barbanana)
        echo $sut->callMarco('banana');     // returns polobanana
    }

    public function test_spy(){
        $spy = $this->spy(SomeDependency::class);
        $sut = new SUT($spy);

        echo $sut->callFoo('banana');       // returns apple (instead of barbanana)
        echo $sut->callMarco('banana');     // returns polobanana

        $spy->shouldHaveReceived('foo')
            ->with('banana');
    }

    public function test_ServiceContainer_withMock(){
        $mock = $this->partialMock(SomeDependency::class, function (MockInterface $mock){
            $mock ->shouldReceive('foo')->once()
                ->andReturn('apple');
        });
        $this->instance(SomeDependency::class, $mock);

        $this->get('/foo');

        $mock->shouldHaveReceived("foo");
    }

    public function test_ServiceContainer_withSpy(){
        $spy = $this->spy(SomeDependency::class);
        $this->instance(SomeDependency::class, $spy);
        $this->get('/foo');
        $spy->shouldHaveReceived("foo");
    }

    public function test_MockingFacades(){
        Cache::shouldReceive('get')
            ->once()
            ->with('key')
            ->andReturn('value');

        $value = Cache::get('key');
    }

    public function test_SpyingFacades(){
        Cookie::spy();

        $value = Cookie::get('key');

        Cookie::shouldHaveReceived('get')->once()->with('key');
    }

    public function test_Fakes(){
        Bus::fake();
        Event::fake();
        Http::fake();
        Mail::fake();
        Notification::fake();
        Queue::fake();
        Storage::fake();
        UploadedFile::fake();
    }

    public function test_FakeExample(){
        Notification::fake();

        $sut = new SUT(new SomeDependency());

        $sut->notify(new testNotification());

        Notification::assertSentTo(
            [$sut], testNotification::class
        );
    }

    public function test_timeTraveling(){
        // Travel into the future...
        echo now()."\n";
        $this->travel(5)->milliseconds();
        echo now()."\n";
        $this->travel(5)->seconds();
        echo now()."\n";
        $this->travel(5)->minutes();
        echo now()."\n";
        $this->travel(5)->hours();
        echo now()."\n";
        $this->travel(5)->days();
        echo now()."\n";
        $this->travel(5)->weeks();
        echo now()."\n";
        $this->travel(5)->years();

        echo now()."\n";


        // Freeze time and resume normal time after executing closure...
        $this->freezeTime(function (Carbon $time) {
            sleep(1);
            echo now()."\n";
            sleep(1);
            echo now()."\n";
            sleep(1);
            echo now()."\n";
        });

        $this->freezeTime(function (Carbon $time) {
            sleep(1);
            echo now()."\n";
            sleep(1);
            echo now()."\n";
            sleep(1);
            echo now()."\n";
        });

        // Travel into the past...
        $this->travel(-5)->hours();
        echo now()."\n";

        // Travel to an explicit time...
        $this->travelTo(now()->subHours(6));
        echo now()."\n";

        // Return back to the present time...
        $this->travelBack();
        echo now()."\n";
    }
}
