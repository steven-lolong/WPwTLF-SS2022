<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Controller;
use App\Events\ButtonClickedAt;
use App\Models\ClickTime;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[Controller::class, 'show']);
Route::get('/button-clicked',function(){
    $clickTime = new ClickTime;
    $clickTime->at = now();
    $clickTimeCount=ClickTime::all()->count();
    $condition = $clickTimeCount <= 10;
    ButtonClickedAt::dispatchIf($condition, $clickTime);
    //ButtonClickedAt::dispatch($clickTime);
    return redirect('/');
})->name('button-clicked');
